package by.htp.Library;

public class Magazine extends PrintedEdition {
	public Magazine(){
		
	}
	public Magazine(double price, String title){
		super(price, title);
	}

}
