package by.htp.Library;

public class Library  {
	private int curentSize;
	private int newSize;
	private int size=curentSize=1;
	private int position=0;
	
	
	PrintedEdition printedEditionArray[] = new PrintedEdition[size];
	

	public PrintedEdition[] getPrintedEditionArray() {
		int i=0;
			if(printedEditionArray[i]==null){
				System.out.println("Your library is empty ");
			}
			else{
				System.out.println("Your library: ");
				if(printedEditionArray[i]!=null){
					for(i=0;i<printedEditionArray.length; i++){
					System.out.println("Printed edition with price "+printedEditionArray[i].getPrice()+"$"+" and title: "+printedEditionArray[i].getTitle());
				}
			}
		}
		return printedEditionArray;
	}
	
	public PrintedEdition[] addPrintedEditionArray(PrintedEdition edition) {
		for(int j=0;j<printedEditionArray.length; j++){
			if (printedEditionArray[j]==null){
				position=j;
				j=printedEditionArray.length;
			}
			else if (j>=position){
				//increase array capacity
				newSize= (curentSize*3)/2+1;
				PrintedEdition printedEditionArrayExtended[] = new PrintedEdition[newSize];
				System.arraycopy(printedEditionArray, 0, printedEditionArrayExtended, 0, printedEditionArray.length);
				curentSize=newSize;
				printedEditionArray=printedEditionArrayExtended;
			}
		}
		printedEditionArray[position]= edition;
		return printedEditionArray;
	}
	
}
