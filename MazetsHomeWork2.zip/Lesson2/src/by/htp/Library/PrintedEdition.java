package by.htp.Library;

public abstract class PrintedEdition {
	private double price;
	private String title;
	//private ���� �����������!!!
	public PrintedEdition(){
		super();
	}
	public PrintedEdition(double price, String title){
		this.price=price;
		this.title=title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
